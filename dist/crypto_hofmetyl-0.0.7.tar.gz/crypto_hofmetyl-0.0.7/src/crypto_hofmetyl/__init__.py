"""Initialize the api"""
from crypto_hofmetyl.api import encrypt_folder as encrypt
from crypto_hofmetyl.api import decrypt_folder as decrypt
