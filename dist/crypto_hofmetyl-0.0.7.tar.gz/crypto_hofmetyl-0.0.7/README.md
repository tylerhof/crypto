# Simple Crypto Package

This is a package which encrypts and decrypts files by a password string.